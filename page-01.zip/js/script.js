    $(document).ready(function(){
          
          $(window).scroll(function(){

            if($(window).scrollTop()>300){
              $('nav').addClass('black');
            }else{
              $('nav').removeClass('black');
            }

          });

     });
      
      $(document).ready(function() {
$(".link").click(function() {
     $('html, body').animate({
         scrollTop: $(".section-01").offset().top
     }, 1500);
 });
});


    